package com.guotai.mall.activity.regist;

/**
 * Created by zhangpan on 17/6/28.
 */

public interface IRegistactivity {

    void SendSuccess(Boolean succ);
    void registSucc(Boolean succ, String mess);
}
