package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/10/31.
 */

public class OrderDetail {

    public String ProductID;
    public String ProductSubID;
    public String Price;
    public int Qty;

}
