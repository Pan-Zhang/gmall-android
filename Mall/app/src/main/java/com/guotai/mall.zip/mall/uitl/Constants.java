package com.guotai.mall.uitl;

/**
 * Created by zhangpan on 17/7/13.
 */

public class Constants {

    // APP_ID 替换为你的应用从官方网站申请到的合法appId
    public static final String APP_ID = "wxd930ea5d5a258f4f";

    /** 支付宝支付业务：入参app_id */
    public static final String APPID = "";
}
