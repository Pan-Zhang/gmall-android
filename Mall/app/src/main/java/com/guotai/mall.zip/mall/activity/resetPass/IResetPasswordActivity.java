package com.guotai.mall.activity.resetPass;

/**
 * Created by zhangpan on 17/10/26.
 */

public interface IResetPasswordActivity {

    void reset(Boolean success);
    void GetSms(Boolean success);
}
