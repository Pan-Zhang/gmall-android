package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/10/19.
 */

public class CarPro extends CollectPro {

    public String ShopCartID;
    public boolean isChoose;
}
