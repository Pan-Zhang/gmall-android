package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/11/29.
 */

public class WxParam {

    public String appid;
    public String partnerid;
    public String prepayid;
    public String _package;
    public String noncestr;
    public String timestamp;
    public String sign;

}
