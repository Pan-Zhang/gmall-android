package com.guotai.mall.activity.splash;

/**
 * Created by zhangpan on 17/10/16.
 */

public interface ISplashActivity {

}
