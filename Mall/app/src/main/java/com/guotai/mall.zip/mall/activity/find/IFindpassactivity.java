package com.guotai.mall.activity.find;

/**
 * Created by zhangpan on 17/6/28.
 */

public interface IFindpassactivity {
}
