package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/10/20.
 */

public class City {

    public String CityID;
    public String CityName;
    public String ZipCode;
    public String ProvinceID;
    public String DateCreated;
    public String DateUpdated;
}
