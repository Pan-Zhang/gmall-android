package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/6/28.
 */

public class Message {

    public String mess;
    public String date;

}
