package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/11/17.
 */

public class LogisticsDetail {

    public String AcceptTime;
    public String AcceptStation;
}
