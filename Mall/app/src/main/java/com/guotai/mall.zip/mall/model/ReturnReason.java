package com.guotai.mall.model;

/**
 * Created by zhangpan on 2018/3/19.
 */

public class ReturnReason {

    public String ReturnReasonID;
    public String ReturnReasonName;
}
