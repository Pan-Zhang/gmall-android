package com.guotai.mall.activity.accountSafe;

/**
 * Created by zhangpan on 17/8/3.
 */

public interface IAccountSafeactivity {
}
