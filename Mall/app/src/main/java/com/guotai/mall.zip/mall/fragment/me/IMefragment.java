package com.guotai.mall.fragment.me;

/**
 * Created by ez on 2017/6/16.
 */

public interface IMefragment {


}
