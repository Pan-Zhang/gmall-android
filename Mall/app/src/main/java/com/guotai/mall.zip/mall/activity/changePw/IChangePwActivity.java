package com.guotai.mall.activity.changePw;

/**
 * Created by zhangpan on 17/11/21.
 */

public interface IChangePwActivity {

    void changePw(boolean success);
}
