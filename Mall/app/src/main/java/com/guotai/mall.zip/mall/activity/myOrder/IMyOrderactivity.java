package com.guotai.mall.activity.myOrder;

/**
 * Created by zhangpan on 17/7/25.
 */

public interface IMyOrderactivity {
}
