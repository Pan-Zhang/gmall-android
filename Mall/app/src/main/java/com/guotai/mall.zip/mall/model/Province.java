package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/10/20.
 */

public class Province {

    public String ProvinceID;
    public String ProvinceName;
    public String DateCreated;
    public String DateUpdated;
}
