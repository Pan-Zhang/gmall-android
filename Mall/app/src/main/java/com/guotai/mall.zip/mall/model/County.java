package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/10/20.
 */

public class County {

    public String DistrictID;
    public String DistrictName;
    public String CityID;
    public String DateCreated;
    public String DateUpdated;
}
