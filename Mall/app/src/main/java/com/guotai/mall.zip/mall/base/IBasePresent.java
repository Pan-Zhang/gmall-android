package com.guotai.mall.base;

/**
 * Created by ez on 2017/4/25.
 */

public interface IBasePresent {
    void destroy();
}
