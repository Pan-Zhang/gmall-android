package com.guotai.mall.activity.CategorySearch;

import com.guotai.mall.model.ProductEx;

/**
 * Created by zhangpan on 2018/4/24.
 */

public interface ICategorySearch {

    void GotoDetail(ProductEx product);
}
