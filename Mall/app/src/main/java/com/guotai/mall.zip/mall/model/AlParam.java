package com.guotai.mall.model;

/**
 * Created by zhangpan on 17/11/29.
 */

public class AlParam {

    public String app_id;
    public String method;
    public String format;
    public String charset;
    public String sign_type;
    public String timestamp;
    public String sign;
    public String _version;
    public String biz_content;
    public String notify_url;
    public String body;
    public String subject;
    public String out_trade_no;
    public String total_amount;
    public String product_code;
    public String goods_type;
    public String passback_params;

}
