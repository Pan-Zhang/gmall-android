package com.guotai.mall.model;

/**
 * Created by ez on 2017/6/20.
 */

public class Address {
    public String UserReceiverID;
    public String UserID;
    public String ReceiverName;
    public String StateName;
    public String ProvinceID;
    public String ProvinceName;
    public String CityID;
    public String CityName;
    public String DistrictID;
    public String DistrictName;
    public String ReceiverAddress;
    public String NationCode;
    public String ReceiverMobile;
    public String CreateTime;
    public String LastUpdatedTime;
    public boolean IsDefault;
}
