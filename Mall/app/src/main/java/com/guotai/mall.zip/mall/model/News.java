package com.guotai.mall.model;

/**
 * Created by ez on 2017/6/20.
 */

public class News {

    public String HotspotID;
    public String HotspotName;
    public String HotspotType;
    public String HotspotLinkUrl;
    public String ImagePath;

}
