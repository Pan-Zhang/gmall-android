package com.guotai.mall.activity.login;

/**
 * Created by zhangpan on 17/6/28.
 */

public interface ILoginactivity {

    void LoginSucc(boolean success);
    void GetSms(boolean success);
}
