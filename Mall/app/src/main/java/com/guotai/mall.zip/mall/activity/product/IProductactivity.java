package com.guotai.mall.activity.product;


import com.guotai.mall.model.ProductEx;

/**
 * Created by ez on 2017/6/16.
 */

public interface IProductactivity {

    void refresh(ProductEx product);

    void addCar(boolean success);

}
