package com.guotai.mall.activity.help;

/**
 * Created by zhangpan on 17/6/27.
 */

public interface IHelpactivity {
}
