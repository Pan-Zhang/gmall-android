package com.guotai.mall.model;

import java.util.List;

/**
 * Created by zhangpan on 17/11/17.
 */

public class Logistics {

    public String EBusinessID;
    public String ShipperCode;
    public String LogisticCode;
    public String Success;
    public String Reason;
    public String State;
    public List<LogisticsDetail> Traces;

}
