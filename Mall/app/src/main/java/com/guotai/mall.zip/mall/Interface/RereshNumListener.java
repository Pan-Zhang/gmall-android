package com.guotai.mall.Interface;

/**
 * Created by zhangpan on 17/8/3.
 */

public interface RereshNumListener {

    void refreshNum();
}
