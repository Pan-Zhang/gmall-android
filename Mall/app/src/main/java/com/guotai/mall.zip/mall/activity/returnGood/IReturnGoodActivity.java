package com.guotai.mall.activity.returnGood;

/**
 * Created by zhangpan on 17/11/2.
 */

public interface IReturnGoodActivity {
}
