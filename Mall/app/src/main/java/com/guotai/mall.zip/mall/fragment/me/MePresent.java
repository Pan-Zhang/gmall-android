package com.guotai.mall.fragment.me;

import com.guotai.mall.base.IBasePresent;

/**
 * Created by ez on 2017/6/26.
 */

public class MePresent implements IBasePresent {
    @Override
    public void destroy() {

    }
}
