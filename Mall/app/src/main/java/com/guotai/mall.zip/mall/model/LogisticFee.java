package com.guotai.mall.model;

/**
 * Created by zhangpan on 2018/4/30.
 */

public class LogisticFee {

    public String LogisticsID;
    public String LogisticsName;
    public String TranportFee;
    public String IsDefault;
}
