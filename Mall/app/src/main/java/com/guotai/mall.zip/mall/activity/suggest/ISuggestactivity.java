package com.guotai.mall.activity.suggest;

/**
 * Created by ez on 2017/6/20.
 */

public interface ISuggestactivity {

}
