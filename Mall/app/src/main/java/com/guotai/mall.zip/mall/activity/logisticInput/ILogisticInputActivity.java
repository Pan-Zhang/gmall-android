package com.guotai.mall.activity.logisticInput;

/**
 * Created by zhangpan on 2018/4/26.
 */

public interface ILogisticInputActivity {
}
